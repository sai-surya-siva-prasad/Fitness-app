# gym-typescript

Build a Complete Typescript React Fitness Application for Beginners

Video: https://www.youtube.com/watch?v=I2NNxr3WPDo

For all related questions and discussions about this project, check out the discord:
https://discord.gg/2FfPeEk2mX
